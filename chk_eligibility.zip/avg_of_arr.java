import java.util.Scanner;

public class avg_of_arr {
  
    public static void main(String args[]){
        int n;
        Scanner scn  = new Scanner(System.in);
        n = scn.nextInt();
       
       System.out.println("enter the element of array");
       int[] arr = new int[10];

       for(int i = 0; i<arr[i]., i++){
        arr[i]= scn.nextInt();
       }
         int sum= 0;
         for(int i=0; i<n; i++){
            sum = sum + arr[i];

         }
         System.out.println("sum of elements of an array"+ sum);
         int avg = sum/10;
         System.out.println("avg of the elements of the array=" + avg);

    
}}
