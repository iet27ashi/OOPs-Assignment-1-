public import java.util.Scanner;
import java.util.Arrays;

public class FindDuplicates {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();

        int[] arr = new int[n];
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = sc.nextInt();
        }

        Arrays.sort(arr);

        System.out.println("Duplicate elements and their frequency:");
        for (int i = 0; i < n - 1; i++) {
            if (arr[i] == arr[i + 1]) {
                int count = 2;
                while (i + 2 < n && arr[i] == arr[i + 2]) {
                    count++;
                    i++;
                }
                System.out.println("Element: " + arr[i] + ", Frequency: " + count);
            }
        }

        sc.close();
    }}

