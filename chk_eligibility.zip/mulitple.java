//Difference between and interface : important qsn

public class mulitple {
    public static void main(String[] args) {
        A7 = new 
    }
    public static void main(String[] args) {
        
    }
    void print();
}
interface Showable{
    void show();
}
class A7 implements Printable,Showable{
    public void print(){
        System.out.println("helo");
    }
    public void show(){
        System.out.println("wlcom");
    }
}
}
