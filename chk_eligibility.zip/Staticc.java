public class Staticc {
    
}
