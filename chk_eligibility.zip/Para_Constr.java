public class Para_Constr {
          public Para_Constr(int num) {
            System.out.println("The number is: " + num);
        }    
        public static void main(String[] args) {
            Para_Constr d = new Para_Constr(42); 
        }
    }
    

