import java.util.Scanner;


public class prime {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int a = scn.nextInt();
        Primee P = new Primee();
        P = findPrime(a);
    }
}
class Primee{
    int a;
   boolean findPrime(int a){
    if((a == 0) || (a == 1)){
        System.out.println("yes prime");}

    for(int i=2; i*i <= a ; i++){
      if(  a%i != 0){
        break;  }
    }
return true;
   }
}
