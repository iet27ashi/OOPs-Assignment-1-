//3. Write a Java program to show parameterized constructor.
public class Student_para {
    String name;
    int id;
    Student_para(int i, String n){
          id = i;
          name = n;
    }
    void display(){
        System.out.println("id:" + id +name);
    }
    public static void main(String[] args) {
        Student_para s1 = new  Student_para(19," Ashi");
        Student_para s2 = new  Student_para(18," Shlok");
        s1.display();
        s2.display();
        
    }
}
