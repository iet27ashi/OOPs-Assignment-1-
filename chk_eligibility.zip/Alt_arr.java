public class Alt_arr {
    public Alt_arr() {
        System.out.println("This is a 0-arguments constructor.");
    }
    public static void main(String[] args) {
        Alt_arr d = new Alt_arr(); 
    }
}

