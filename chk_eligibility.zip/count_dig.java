import java.util.Scanner;
public class count_dig {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        int num = scn.nextInt();
     count c = new count();
    int d = c.countfun(num);  
    System.out.println("num of digit=" + d); 
    }
}
class count{
   public int countfun(int num){
    int count =0;
        while(num != 0){
            
            num = num/10;

            count +=1;
            
        }
        return count;

    }
   
}