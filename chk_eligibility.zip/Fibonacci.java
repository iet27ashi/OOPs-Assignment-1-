
//write java program for fibonacci series

public class Fibonacci {
public static void main(String[] args) {
    int n = 12;

}
}
class fibo{
    int findFibo(int n){
        int f = a+b;
        int temp = a;
        int b  = temp;
        int a = b;

    }
}
