public import java.util.Scanner;

public class Queue {
    private int[] queue;
    private int front;
    private int rear;
    private int size;

    public Queue(int size) {
        this.size = size;
        queue = new int[size];
        front = -1;
        rear = -1;
    }

    public void enqueue(int value) {
        if (rear == size - 1) {
            System.out.println("Queue Overflow! Cannot enqueue " + value);
        } else {
            if (front == -1) {
                front = 0;
            }
            queue[++rear] = value;
            System.out.println("Enqueued: " + value);
        }
    }

    public int dequeue() {
        if (front == -1 || front > rear) {
            System.out.println("Queue Underflow! No elements to dequeue.");
            return -1;
        } else {
            return queue[front++];
        }
    }

    public int peek() {
        if (front == -1 || front > rear) {
            System.out.println("Queue is empty. No front element.");
            return -1;
        } else {
            return queue[front];
        }
    }

    public boolean isEmpty() {
        return front == -1 || front > rear;
    }

    public void display() {
        if (front == -1 || front > rear) {
            System.out.println("Queue is empty.");
        } else {
            System.out.print("Queue elements: ");
            for (int i = front; i <= rear; i++) {
                System.out.print(queue[i] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter the size of the queue: ");
        int size = input.nextInt();

        Queue queue = new Queue(size);

        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        queue.display();

        System.out.println("Dequeued element: " + queue.dequeue());
        System.out.println("Front element: " + queue.peek());
        queue.display();

        input.close();
    }
}

