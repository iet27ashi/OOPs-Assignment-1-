public class Palindrome {
    int chkPalindrome(int n){
        int original = n;
    
        int ld = n%10;
        n = n/10;
    }
}
